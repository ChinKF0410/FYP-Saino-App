const express = require('express');
const { login, register, verifyEmail, sendVerificationEmail, logout } = require('../controllers/userController');

const router = express.Router();

router.post('/login', login);
router.post('/register', register);
router.get('/verify-email', verifyEmail);
router.post('/send-verification-email', sendVerificationEmail);
router.post('/logout', logout);

module.exports = router;

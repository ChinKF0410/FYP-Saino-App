import 'dart:convert';
import 'package:http/http.dart' as http;
import 'auth_provider.dart';
import 'auth_user.dart';
import 'auth_exception.dart';
import 'dart:developer' as devtools show log;

class MSSQLAuthProvider implements AuthProvider {
  final String baseUrl =
      "http://10.0.2.2:3000/api"; // Use localhost for backend URL

  AuthUser? _currentUser;

  @override
  Future<AuthUser> login({
    required String email,
    required String password,
    required String username,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'email': email,
          'password': password,
          'username': username,
        }),
      );

      devtools
          .log('Login API Response: ${response.statusCode} ${response.body}');
      devtools.log(username);
      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        _currentUser = AuthUser(
          id: responseData['id'],
          username: responseData['username'],
          email: email,
          isEmailVerified:
              true, // Assuming the user is verified for this example
        );
        return _currentUser!;
      } else if (response.statusCode == 404) {
        throw UserNotFoundAuthException();
      } else if (response.statusCode == 401) {
        throw WrongPasswordAuthException();
      } else {
        throw GenericAuthException();
      }
    } catch (e) {
      devtools.log('Login Error: $e');
      throw GenericAuthException();
    }
  }

  @override
  Future<AuthUser> register({
    required String username,
    required String email,
    required String password,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/register'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'username': username,
          'email': email,
          'password': password,
        }),
      );

      devtools.log(
          'Register API Response: ${response.statusCode} ${response.body}');
      devtools.log(username);
      devtools.log(email);

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        _currentUser = AuthUser(
          id: responseData['id'],
          username: responseData['username'],
          email: email,
          isEmailVerified: false, // Assume verification required
        );
        return _currentUser!;
      } else if (response.statusCode == 400) {
        throw EmailAlreadyInUseAuthException();
      } else {
        throw GenericAuthException();
      }
    } catch (e) {
      devtools.log('Register Error: $e');
      throw GenericAuthException();
    }
  }

  @override
  Future<void> sendEmailVerification() async {
    // Implement email verification if necessary
  }

  @override
  Future<void> logout() async {
    _currentUser = null;
    // Implement logout logic if necessary
  }

  @override
  AuthUser? get currentUser => _currentUser;

  @override
  Future<void> initialize() async {
    // Implement any initialization logic if necessary
  }
}

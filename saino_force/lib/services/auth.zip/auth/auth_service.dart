import 'auth_provider.dart';
import 'auth_user.dart';
import 'MSSQLAuthProvider.dart';

class AuthService implements AuthProvider {
  static final AuthService _instance = AuthService._internal(MSSQLAuthProvider());
  final AuthProvider provider;

  AuthService._internal(this.provider);

  factory AuthService.mssql() => _instance;

  @override
  Future<AuthUser> login({
    required String email,
    required String password,
    required String username,
  }) => provider.login(email: email, password: password, username: username);

  @override
  Future<AuthUser> register({
    required String username,
    required String email,
    required String password,
  }) => provider.register(username: username, email: email, password: password);

  @override
  Future<void> sendEmailVerification() => provider.sendEmailVerification();

  @override
  Future<void> logout() => provider.logout();

  @override
  AuthUser? get currentUser => provider.currentUser;

  @override
  Future<void> initialize() => provider.initialize();
}
